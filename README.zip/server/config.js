export default {
  JWT_SECRET: "Jto5COhIpl2pREZ95fpgkPPSeplJOkqv2o6Z9IoMJPY=",
  ATLAS_URI:
    "mongodb+srv://admin:admin123@cluster0.qeozd0b.mongodb.net/?retryWrites=true&w=majority",
};
